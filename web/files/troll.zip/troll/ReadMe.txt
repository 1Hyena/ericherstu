Troll is a freeware video game that has been greatly inspired by Prehistorik 2.

Author   : Erich Erstu
version  : 1.10
Released : 10. August 2004

The game has been created on a computer with the following parameters.
Celeron : 1000 MHz
Ram     : 128 MiB
Video   : 32 MiB

The game could feel a bit too difficult on the first try but actually it just
requires some practice. The author managed to gain 80 lives by the 16th level.

The game has 20 levels in total where each of them offers something different.


Story:

You are a troll named Thog and on one day when going for a hunt you discovered
that all the beasts of the woods have gone crazy. They attacked you more than
ever before. On a way back home you heard a faint trumpet from the distance.
You knew very well the meaning of such a trumpet as it was the emergency signal
that the kingdom is under attack and that the castle has fallen. In an instant
you set your sight on the castle and start traveling towards it because the king
may need your help.


Tips and tricks:

 1. Before you jump, try to crouch. Then you will jump higher.
 2. When you move in the crouching position you will have more strength.
 3. Try to hit bushes and cracks because there are many hidden secrets.
 4. If you get stuck in an elevator, then F12 is the key that kills you.
 5. Press UP, then release it and hold the right arrow key to cross water.
 6. Bears and other beasts will get extra aggressive if they smell bones.
 7. Believe the white labels as they are often times clues meant to help you.
 8. The end boss is very strong but there is a secret wall you can pass through.
 9. Get the key in the swamp even though the level can be completed without it.
10. Want extra lives? Then start the first level with its password.
